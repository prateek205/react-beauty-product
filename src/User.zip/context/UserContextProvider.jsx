import React, { useState } from "react";
import { MyContext } from "./UserContext";
import { useNavigate } from "react-router-dom";

const UserContextProvider = ({ children }) => {
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [errors, setErrors] = useState({});
  const [showPass, setShowPass] = useState(true);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
  });
  const navigate = useNavigate();

  // Login
  const login = async (e) => {
    e.preventDefault();

    const res = await fetch(
      `http://localhost:5000/users?email=${email}&password=${pass}`,
    );
    const users = await res.json();

    if (users.length > 0) {
      localStorage.setItem("userId", users[0].id);
      console.log("id:", users[0].id);
      navigate("/my_profile");
    } else {
      alert("User not found!");
    }
  };

  // register

  const validate = () => {
    let newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = "Name is Required";
    }

    if (!formData.email) {
      newErrors.email = "Email is Required";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "invalid Email Id";
    }

    if (!formData.password) {
      newErrors.password = "Password is Required";
    } else if (formData.password.length < 8) {
      newErrors.password = "Password must be atleast 8 characters";
    }

    return newErrors;
  };

  const handleRegister = async (e) => {
    e.preventDefault();

    const validationErrors = validate();
    setErrors(validationErrors);

    setTimeout(() => {
      setErrors({});
    }, 2000);

    const response = await fetch("http://localhost:5000/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formData),
    });

    const data = await response.json();

    console.log("user added", data);

    if (response.ok) {
      alert("Registration is Successfully");
      navigate("/login");
    } else {
      alert("Register failed!!");
    }
  };

  return (
    <MyContext.Provider
      value={{
        handleRegister,
        formData,
        setFormData,
        errors,
        setErrors,
        login,
        email,
        setEmail,
        pass,
        setPass,
        showPass,
        setShowPass,
      }}
    >
      {children}
    </MyContext.Provider>
  );
};

export default UserContextProvider;
