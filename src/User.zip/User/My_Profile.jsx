import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const My_Profile = () => {
  const navigate = useNavigate();
  const [userData, setUserData] = useState({
    name: "",
    email: "",
    password: "",
  });

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user"));

    if (user) {
      setUserData(user);
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("user");
    navigate("/login");
  };

  return (
    <div className="h-screen flex flex-col gap-5 items-center p-5 bg-pink-100">
      <h1 className="text-4xl font-bold">My_Profile</h1>
      <div className="rounded-md w-1/2 h-full py-2 px-2 bg-white shadow-lg shadow-gray-400">
        <form action="" className="flex flex-col gap-14">
          <div className="flex items-end justify-around">
            <img
              src="/body-wash.webp"
              alt=""
              className="rounded-full flex items-center justify-center shadow-md shadow-gray-400 object-contain w-64 h-64"
            />
            <input type="file" name="" id="" />
          </div>
          <input
            className="shadow-md shadow-gray-400 outline-none rounded-md p-2"
            type="text"
            value={userData.name}
            onChange={(e) => setUserData({ ...userData, name: e.target.value })}
            placeholder="Full Name"
          />
          <input
            className="shadow-md shadow-gray-400 outline-none rounded-md p-2"
            type="email"
            value={userData.email}
            onChange={(e) =>
              setUserData({ ...userData, email: e.target.value })
            }
            placeholder="Email Address"
          />
          <input
            className="shadow-md shadow-gray-400 outline-none rounded-md p-2"
            type="password"
            value={userData.password}
            onChange={(e) =>
              setUserData({ ...userData, password: e.target.value })
            }
            placeholder="Password"
          />
          <button
            onClick={handleLogout}
            className="bg-gray-300 text-xl p-2 w-64 m-auto flex items-center justify-center rounded-md font-bold cursor-pointer hover:bg-pink-200 shadow-lg shadow-gray-400"
          >
            Logout
          </button>
        </form>
      </div>
    </div>
  );
};

export default My_Profile;
